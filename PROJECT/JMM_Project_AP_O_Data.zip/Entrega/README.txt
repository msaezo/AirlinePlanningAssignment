Code information:
 - All other TXT files should be changed .m extension to be run in MATLAB
 - Folders "Figures" and "LPFiles" must be created in the working directory prior to running any of the codes
 - CPLEX must be included in MATLAB path before running the programs